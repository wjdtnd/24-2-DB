package Library;

public class BookDTO {

    String inputTitle;
    String inputAuthor;
    String inputPublisher;
    String inputPrice;
    String inputGenre;
    String inputPage;
    String inputLanguage;
    String inputISBN;
    String inputYear;
    boolean inputBoolean;


    public String getInputTitle() {
        return inputTitle;
    }

    public void setInputTitle(String inputTitle) {
        this.inputTitle = inputTitle;
    }

    public String getInputAuthor() {
        return inputAuthor;
    }

    public void setInputAuthor(String inputAuthor) {
        this.inputAuthor = inputAuthor;
    }

    public String getInputPublisher() {
        return inputPublisher;
    }

    public void setInputPublisher(String inputPublisher) {
        this.inputPublisher = inputPublisher;
    }

    public String getInputPrice() {
        return inputPrice;
    }

    public void setInputPrice(String inputPrice) {
        this.inputPrice = inputPrice;
    }

    public String getInputGenre() {
        return inputGenre;
    }

    public void setInputGenre(String inputGenre) {
        this.inputGenre = inputGenre;
    }

    public String getInputPage() {
        return inputPage;
    }

    public void setInputPage(String inputPage) {
        this.inputPage = inputPage;
    }

    public String getInputLanguage() {
        return inputLanguage;
    }

    public void setInputLanguage(String inputLanguage) {
        this.inputLanguage = inputLanguage;
    }

    public String getInputISBN() {
        return inputISBN;
    }

    public void setInputISBN(String inputISBN) {
        this.inputISBN = inputISBN;
    }

    public String getInputYear() {
        return inputYear;
    }

    public void setInputYear(String inputYear) {
        this.inputYear = inputYear;
    }

    public boolean isInputBoolean() {
        return inputBoolean;
    }

    public void setInputBoolean(boolean inputBoolean) {
        this.inputBoolean = inputBoolean;
    }








}
