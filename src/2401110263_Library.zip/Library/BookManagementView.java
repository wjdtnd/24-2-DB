package Library;

public class BookManagementView {

    public void printTitle() {
        System.out.println("=== 도서 관리 시스템 ===");
    }

    public void printMiddle() {
        System.out.println("작업이 완료되었습니다. 계속 진행하려면 메뉴를 선택하세요.");
    }

    public void printFooter() {
        System.out.println("프로그램을 종료합니다.");
    }
}
